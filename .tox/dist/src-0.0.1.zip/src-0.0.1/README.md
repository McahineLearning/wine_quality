1. create enviournment
2. activate the env
3. make requirements.txt
4. install the requirements
5. git init
6. dvc init
7. dvc add data_given/winequalityN.csv
8. git add .
9. git commit -m "first commit"