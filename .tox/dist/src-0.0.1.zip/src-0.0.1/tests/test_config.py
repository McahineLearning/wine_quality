def test_geneirc():
    a =  2
    b = 2
    assert a!= b